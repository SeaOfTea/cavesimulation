/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/

#include "StdAfx.h"

#ifdef WIN32
HINSTANCE hInstance = NULL;

BOOL WINAPI DllMain(HINSTANCE _hInstance, ULONG UNUSED(fdwReason), LPVOID UNUSED(lpvReserved))
{
	hInstance = _hInstance;
	return TRUE;
}

#include "FMath/FMColor.h"
#include "FUtils/FUDebug.h"
#include "FUtils/FULogFile.h"
#include "FUtils/FUBoundingBox.h"
#include "FUtils/FUBoundingSphere.h"
#include "FCDocument/FCDocument.h"
#include "FCDocument/FCDAnimationClipTools.h"

// Trick the linker so that it adds the functionalities of the classes that are not used internally.
FCOLLADA_EXPORT void TrickLinker()
{
	// FMColor
	FMColor* color = NULL;
	float* f = NULL;
	color->ToFloats(f, 4);

	// FULogFile
	FULogFile* logFile = NULL;
	logFile->WriteLine("Test");

	// FUBoundingBox and FUBoundingSphere
	FUBoundingBox bb;
	FUBoundingSphere ss;
	if (!bb.Overlaps(ss))
	{
		// FUDebug
		DEBUG_OUT("Tricking Linker...");
	}

	// FCDAnimationClipTools
	FCDocument* d = FCollada::NewTopDocument();
	FCDAnimationClipTools::ResetAnimationClipTimes(d, 0.0f);
	d->Release();
}
#endif //WIN32
