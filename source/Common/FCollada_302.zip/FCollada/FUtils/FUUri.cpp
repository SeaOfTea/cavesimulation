/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/

#include "StdAfx.h"
#include "FUtils/FUStringConversion.h"
#include "FUtils/FUUri.h"

FUUri::FUUri()
{
}

FUUri::FUUri(const fm::string& uri)
{
	size_t index = uri.find('#');
	if (index == fm::string::npos) suffix = uri;
	else
	{
		prefix = TO_FSTRING(uri.substr(0, index));
		suffix = uri.substr(index + 1);
	}
}

#ifdef UNICODE
FUUri::FUUri(const fstring& uri)
{
	size_t index = uri.find('#');
	if (index == fstring::npos) suffix = TO_STRING(uri);
	else
	{
		prefix = uri.substr(0, index);
		suffix = TO_STRING(uri.substr(index + 1));
	}
}
#endif // UNICODE
