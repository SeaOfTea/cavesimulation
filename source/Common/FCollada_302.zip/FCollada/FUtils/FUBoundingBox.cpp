/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/

#include "StdAfx.h"
#include "FUtils/FUBoundingBox.h"
#include "FUtils/FUBoundingSphere.h"

//
// FUBoundingBox
//

FUBoundingBox::FUBoundingBox()
:	minimum(FLT_MAX, FLT_MAX, FLT_MAX)
,	maximum(-FLT_MAX, -FLT_MAX, -FLT_MAX)
{
}

FUBoundingBox::FUBoundingBox(const FMVector3& _min, const FMVector3& _max)
:	minimum(_min), maximum(_max)
{
}

FUBoundingBox::FUBoundingBox(const FUBoundingBox& copy)
:	minimum(copy.minimum), maximum(copy.maximum)
{
}

FUBoundingBox::~FUBoundingBox()
{
}

void FUBoundingBox::Reset()
{
	minimum = FMVector3(FLT_MAX, FLT_MAX, FLT_MAX);
	maximum = FMVector3(-FLT_MAX, -FLT_MAX, -FLT_MAX);
}

bool FUBoundingBox::IsValid() const
{
	return minimum.x < maximum.x && minimum.y < maximum.y && minimum.z < maximum.z;
}

bool FUBoundingBox::Contains(const FMVector3& point) const
{
	return minimum.x <= point.x && point.x <= maximum.x
		&& minimum.y <= point.y && point.y <= maximum.y
		&& minimum.z <= point.z && point.z <= maximum.z;
}

bool FUBoundingBox::Overlaps(const FUBoundingBox& boundingBox, FMVector3* overlapCenter) const
{
	bool overlaps = minimum.x <= boundingBox.maximum.x && boundingBox.minimum.x <= maximum.x
		&& minimum.y <= boundingBox.maximum.y && boundingBox.minimum.y <= maximum.y
		&& minimum.z <= boundingBox.maximum.z && boundingBox.minimum.z <= maximum.z;
	if (overlaps && overlapCenter != NULL)
	{
		float overlapMinX = max(minimum.x, boundingBox.minimum.x);
		float overlapMaxX = min(maximum.x, boundingBox.maximum.x);
		float overlapMinY = max(minimum.y, boundingBox.minimum.y);
		float overlapMaxY = min(maximum.y, boundingBox.maximum.y);
		float overlapMinZ = max(minimum.z, boundingBox.minimum.z);
		float overlapMaxZ = min(maximum.z, boundingBox.maximum.z);
		(*overlapCenter) = FMVector3((overlapMaxX + overlapMinX) / 2.0f, (overlapMaxY + overlapMinY) / 2.0f, (overlapMaxZ + overlapMinZ) / 2.0f);
	}
	return overlaps;
}

bool FUBoundingBox::Overlaps(const FUBoundingSphere& boundingSphere, FMVector3* overlapCenter) const
{
	// already implemented in bounding sphere code.
	return boundingSphere.Overlaps(*this, overlapCenter);
}

void FUBoundingBox::Include(const FUBoundingBox& boundingBox)
{
	 const FMVector3& n = boundingBox.minimum; 
	 const FMVector3& x = boundingBox.maximum; 
	 minimum.x = min(minimum.x, n.x); 
	 minimum.y = min(minimum.y, n.y); 
	 minimum.z = min(minimum.z, n.z); 
	 maximum.x = max(maximum.x, x.x); 
	 maximum.y = max(maximum.y, x.y); 
	 maximum.z = max(maximum.z, x.z);
}

void FUBoundingBox::Include(const FMVector3& point)
{
	minimum.x = min(minimum.x, point.x);
	minimum.y = min(minimum.y, point.y);
	minimum.z = min(minimum.z, point.z);
	maximum.x = max(maximum.x, point.x);
	maximum.y = max(maximum.y, point.y);
	maximum.z = max(maximum.z, point.z);
}

FUBoundingBox FUBoundingBox::Transform(const FMMatrix44& transform) const
{
	if (!IsValid()) return (*this);

	FUBoundingBox transformedBoundingBox;

	FMVector3 testPoints[6] =
	{
		FMVector3(minimum.x, maximum.y, minimum.z), FMVector3(minimum.x, maximum.y, maximum.z),
		FMVector3(maximum.x, maximum.y, minimum.z), FMVector3(minimum.x, minimum.y, maximum.z),
		FMVector3(maximum.x, minimum.y, minimum.z), FMVector3(maximum.x, minimum.y, maximum.z)
	};

	for (size_t i = 0; i < 6; ++i)
	{
		testPoints[i] = transform.TransformCoordinate(testPoints[i]);
		transformedBoundingBox.Include(testPoints[i]);
	}
	transformedBoundingBox.Include(transform.TransformCoordinate(minimum));
	transformedBoundingBox.Include(transform.TransformCoordinate(maximum));

	return transformedBoundingBox;
}

