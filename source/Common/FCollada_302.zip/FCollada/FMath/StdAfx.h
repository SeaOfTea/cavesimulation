/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/

#ifndef _STD_AFX_H_
#define _STD_AFX_H_

#define NO_LIBXML
#include "FUtils/FUtils.h"

#endif // _STD_AFX_H_
