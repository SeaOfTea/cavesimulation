/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/

#include "StdAfx.h"
#include "FMath/FMInterpolation.h"

// TODO: Move the float-float interpolations here, instead of within the animation system: va_list, anyone?
