/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/

#include "StdAfx.h"
#include "FCDocument/FCDocument.h"
#include "FCDocument/FCDEntity.h"
#include "FCDocument/FCDExternalReference.h"
#include "FCDocument/FCDLibrary.h"
#include "FCDocument/FCDPhysicsMaterial.h"
#include "FCDocument/FCDPhysicsModel.h"
#include "FCDocument/FCDPhysicsModelInstance.h"
#include "FCDocument/FCDPhysicsRigidBody.h"
#include "FCDocument/FCDPhysicsRigidBodyInstance.h"
#include "FCDocument/FCDPhysicsParameter.h"
#include "FCDocument/FCDPhysicsParameter.hpp"
#include "FCDocument/FCDSceneNode.h"
#include "FUtils/FUDaeParser.h"
#include "FUtils/FUDaeWriter.h"
using namespace FUDaeParser;
using namespace FUDaeWriter;

ImplementObjectType(FCDPhysicsRigidBodyInstance);

FCDPhysicsRigidBodyInstance::FCDPhysicsRigidBodyInstance(FCDocument* document, FCDPhysicsModelInstance* _parent)
:	FCDEntityInstance(document, NULL, FCDEntity::PHYSICS_RIGID_BODY)
,	parent(_parent)
,	physicsMaterial(NULL), ownsPhysicsMaterial(false)
{
	instanceMaterialRef = NULL;
}

FCDPhysicsRigidBodyInstance::~FCDPhysicsRigidBodyInstance()
{
	parent = NULL;
	SAFE_DELETE(instanceMaterialRef);

	if (ownsPhysicsMaterial)
	{
		SAFE_RELEASE(physicsMaterial);
	}
	else
	{
		physicsMaterial = NULL;
	}
}

void FCDPhysicsRigidBodyInstance::AddParameter(FCDPhysicsParameterGeneric* parameter)
{
	parameters.push_back(parameter);
	SetDirtyFlag();
}

void FCDPhysicsRigidBodyInstance::SetPhysicsMaterial(FCDPhysicsMaterial* material)
{
	if (ownsPhysicsMaterial) SAFE_RELEASE(physicsMaterial);
	physicsMaterial = material;
	ownsPhysicsMaterial = false;
	SetDirtyFlag();
}

FCDPhysicsMaterial* FCDPhysicsRigidBodyInstance::AddOwnPhysicsMaterial()
{
	if (ownsPhysicsMaterial) SAFE_RELEASE(physicsMaterial);
	physicsMaterial = new FCDPhysicsMaterial(GetDocument());
	ownsPhysicsMaterial = true;
	SetDirtyFlag();
	return physicsMaterial;
}

FCDEntityInstance* FCDPhysicsRigidBodyInstance::Clone(FCDEntityInstance* _clone) const
{
	FCDPhysicsRigidBodyInstance* clone = NULL;
	if (_clone == NULL) _clone = clone = new FCDPhysicsRigidBodyInstance(const_cast<FCDocument*>(GetDocument()), NULL);
	else if (_clone->HasType(FCDPhysicsRigidBodyInstance::GetClassType())) clone = (FCDPhysicsRigidBodyInstance*) _clone;

	Parent::Clone(_clone);
	
	if (clone != NULL)
	{
		// Clone the physics parameter
		for (FCDPhysicsParameterContainer::const_iterator it = parameters.begin(); it != parameters.end(); ++it)
		{
			// This is INCORRECT: the parameters are created under the wrong document.
			clone->parameters.push_back((*it)->Clone());
		}

		// Intentionally leave the target scene node as NULL.

		if (physicsMaterial != NULL)
		{
			if (IsLocal(clone))
			{
				// Share the physics material.
				clone->SetPhysicsMaterial(const_cast<FCDPhysicsMaterial*>(&*physicsMaterial));
			}
			else
			{
				// Clone the physics material.
				FCDPhysicsMaterial* clonedMaterial = clone->GetDocument()->GetPhysicsMaterialLibrary()->AddEntity();
				physicsMaterial->Clone(clonedMaterial);
				clone->SetPhysicsMaterial(clonedMaterial);
			}
		}

		// Clone the material instance
		if (instanceMaterialRef != NULL)
		{
			clone->instanceMaterialRef = new FCDEntityInstance(clone->GetDocument(), NULL, instanceMaterialRef->GetEntityType());
			instanceMaterialRef->Clone(clone->instanceMaterialRef);
		}
	}
	return _clone;
}

// Load the geometry instance from the COLLADA document
bool FCDPhysicsRigidBodyInstance::LoadFromXML(xmlNode* instanceNode)
{
	bool status = FCDEntityInstance::LoadFromXML(instanceNode);
	if (!status) return status;

	// Check for the expected instantiation node type
	if (!IsEquivalent(instanceNode->name, DAE_INSTANCE_RIGID_BODY_ELEMENT) || parent == NULL)
	{
		FUError::Error(FUError::ERROR, FUError::ERROR_UNKNOWN_ELEMENT, instanceNode->line);
		status = false;
	}

	// Find the target scene node/rigid body
	fm::string targetNodeId = ReadNodeProperty(instanceNode, DAE_TARGET_ATTRIBUTE);
	targetNode = GetDocument()->FindSceneNode(SkipPound(targetNodeId));
	if (!targetNode)
	{
		//return status.Fail(FS("Couldn't find target node for instantiation of rigid body"), instanceNode->line);
		FUError::Error(FUError::ERROR, FUError::WARNING_MISSING_URI_TARGET, instanceNode->line);
	}

	// Find the instantiated rigid body
	fm::string physicsRigidBodySid = ReadNodeProperty(instanceNode, DAE_BODY_ATTRIBUTE);
	if (parent->GetEntity() != NULL &&  parent->GetEntity()->GetType() == FCDEntity::PHYSICS_MODEL)
	{
		FCDPhysicsModel* model = (FCDPhysicsModel*) parent->GetEntity();
		FCDPhysicsRigidBody* body = model->FindRigidBodyFromSid(physicsRigidBodySid);
		if (body == NULL)
		{
			FUError::Error(FUError::ERROR, FUError::WARNING_MISSING_URI_TARGET, instanceNode->line);
			return false;
		}
		SetEntity(body);
	}

	//Read in the same children as rigid_body + velocity and angular_velocity
	xmlNode* techniqueNode = FindChildByType(instanceNode, DAE_TECHNIQUE_COMMON_ELEMENT);
	xmlNode* param = FindChildByType(techniqueNode, DAE_DYNAMIC_ELEMENT);
	if (param != NULL)
	{
		AddParameter(DAE_DYNAMIC_ELEMENT, FUStringConversion::ToBoolean(ReadNodeContentDirect(param)));
	}

	xmlNode* massFrame;
	massFrame = FindChildByType(techniqueNode, DAE_MASS_FRAME_ELEMENT);
	if (massFrame)
	{
        param = FindChildByType(massFrame, DAE_TRANSLATE_ELEMENT);
		if (param != NULL)
		{
			AddParameter(DAE_TRANSLATE_ELEMENT, FUStringConversion::ToVector3(ReadNodeContentDirect(param)));
		}
		xmlNodeList rotates;
		FindChildrenByType(massFrame, DAE_ROTATE_ELEMENT, rotates);
		for(xmlNodeList::iterator it = rotates.begin(); it != rotates.end(); it++)
		{
			FCDPhysicsParameter<FMVector4>* p = new FCDPhysicsParameter<FMVector4>(GetDocument(), DAE_ROTATE_ELEMENT);
			p->SetValue(FUStringConversion::ToVector4(ReadNodeContentDirect(*it)));
			AddParameter(p);
		}
	}
	param = FindChildByType(techniqueNode, DAE_INERTIA_ELEMENT);
	if (param != NULL) 
	{
		AddParameter(DAE_INERTIA_ELEMENT, FUStringConversion::ToVector3(ReadNodeContentDirect(param)));
	}

	param = FindChildByType(techniqueNode, DAE_MASS_ELEMENT);
	if (param != NULL)
	{
		AddParameter(DAE_MASS_ELEMENT, FUStringConversion::ToFloat(ReadNodeContentDirect(param)));
	}

	param = FindChildByType(techniqueNode, DAE_PHYSICS_MATERIAL_ELEMENT);
	if (param != NULL) 
	{
		FCDPhysicsMaterial* material = AddOwnPhysicsMaterial();
		material->LoadFromXML(param);
	}
	else
	{
		param = FindChildByType(techniqueNode, DAE_INSTANCE_PHYSICS_MATERIAL_ELEMENT);
		if (param != NULL)
		{
			instanceMaterialRef = new FCDEntityInstance(GetDocument(), NULL, FCDEntity::PHYSICS_MATERIAL);
			instanceMaterialRef->LoadFromXML(param);
			FCDPhysicsMaterial* material = (FCDPhysicsMaterial*) instanceMaterialRef->GetEntity();
			if (material == NULL)
			{
				FUError::Error(FUError::ERROR, FUError::WARNING_MISSING_URI_TARGET, instanceNode->line);
			}
			SetPhysicsMaterial(material);
		}
	}
	
	param = FindChildByType(techniqueNode, DAE_VELOCITY_ELEMENT);
	if (param != NULL)
	{
		AddParameter(DAE_VELOCITY_ELEMENT, FUStringConversion::ToVector3(ReadNodeContentDirect(param)));
	}
	param = FindChildByType(techniqueNode, DAE_ANGULAR_VELOCITY_ELEMENT);
	if (param != NULL)
	{
		AddParameter(DAE_ANGULAR_VELOCITY_ELEMENT, FUStringConversion::ToVector3(ReadNodeContentDirect(param)));
	}

	SetDirtyFlag();
	return status;
}

FCDPhysicsRigidBody* FCDPhysicsRigidBodyInstance::FlattenRigidBody()
{
	FCDPhysicsRigidBody* rigidBody = (FCDPhysicsRigidBody*) GetEntity(); 
	FCDPhysicsRigidBody* clone = NULL;
	if (rigidBody != NULL)
	{
		clone = (FCDPhysicsRigidBody*) rigidBody->Clone();
		clone->Flatten();

		for (FCDPhysicsParameterContainer::iterator itP = parameters.begin(); itP != parameters.end(); ++itP)
		{
			FCDPhysicsParameterGeneric* param = clone->FindParameterByReference((*itP)->GetReference());
			if (param != NULL)
			{
				(*itP)->Overwrite(param);
			}
			else
			{
				clone->CopyParameter(*itP);
			}
		}

		if (physicsMaterial)
			clone->SetPhysicsMaterial(physicsMaterial);
	}

	return clone;
}

// Write out the instantiation information to the XML node tree
xmlNode* FCDPhysicsRigidBodyInstance::WriteToXML(xmlNode* parentNode) const
{
	xmlNode* instanceNode = FCDEntityInstance::WriteToXML(parentNode);

	AddAttribute(instanceNode, DAE_TARGET_ATTRIBUTE, fm::string("#") + targetNode->GetDaeId());
	AddAttribute(instanceNode, DAE_BODY_ATTRIBUTE, GetEntity()->GetDaeId());

	//inconsistency in the spec
	RemoveAttribute(instanceNode, DAE_URL_ATTRIBUTE);
	
	xmlNode* techniqueNode = AddChild(instanceNode, DAE_TECHNIQUE_COMMON_ELEMENT);
	for(FCDPhysicsParameterContainer::const_iterator it = parameters.begin(); it!= parameters.end(); it++)
	{
		(*it)->WriteToXML(techniqueNode);
	}
	//the translate and rotate elements need to be in a <mass_frame> tag. Go figure.
	xmlNodeList transforms;
	FindChildrenByType(techniqueNode, DAE_TRANSLATE_ELEMENT, transforms);
	FindChildrenByType(techniqueNode, DAE_ROTATE_ELEMENT, transforms);
	if (!transforms.empty())
	{
		xmlNode* massFrameNode = AddChild(techniqueNode, DAE_MASS_FRAME_ELEMENT);
		for(xmlNodeList::iterator it = transforms.begin(); it != transforms.end(); it++)
		{
			ReParentNode(*it, massFrameNode);
		}
	}

	if (ownsPhysicsMaterial && physicsMaterial)
	{
		xmlNode* materialNode = AddChild(techniqueNode, DAE_PHYSICS_MATERIAL_ELEMENT);
		physicsMaterial->WriteToXML(materialNode);
	}
	else if (instanceMaterialRef)
	{
		instanceMaterialRef->WriteToXML(techniqueNode);
//		xmlNode* materialNode = AddChild(techniqueNode, DAE_INSTANCE_PHYSICS_MATERIAL_ELEMENT);
//		AddAttribute(materialNode, DAE_SID_ATTRIBUTE, instanceMaterialRef->GetSid());
//		AddAttribute(materialNode, DAE_NAME_ATTRIBUTE, instanceMaterialRef->GetName());
//		AddAttribute(materialNode, DAE_URL_ATTRIBUTE, instanceMaterialRef->GetUri().suffix);
	}

	return instanceNode;
}
