/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/

#include "StdAfx.h"
#include "FCDocument/FCDocument.h"
#include "FCDocument/FCDEmitter.h"
#include "FCDocument/FCDEmitterInstance.h"
#include "FCDocument/FCDEntity.h"
#include "FCDocument/FCDExtra.h"
#include "FCDocument/FCDGeometryPolygons.h"
#include "FCDocument/FCDLibrary.h"
#include "FCDocument/FCDMaterial.h"
#include "FCDocument/FCDMaterialInstance.h"
#include "FUtils/FUDaeParser.h"
#include "FUtils/FUDaeWriter.h"
using namespace FUDaeParser;
using namespace FUDaeWriter;

//
// FCDEmitterInstance
//

ImplementObjectType(FCDEmitterInstance);

FCDEmitterInstance::FCDEmitterInstance(FCDocument* document, FCDSceneNode* parent, FCDEntity::Type entityType)
:	FCDEntityInstance(document, parent, entityType)
{
}

FCDEmitterInstance::~FCDEmitterInstance()
{
}

FCDEntityInstance* FCDEmitterInstance::Clone(FCDEntityInstance* _clone) const
{
	FCDEmitterInstance* clone = NULL;
	if (_clone == NULL) _clone = clone = new FCDEmitterInstance(const_cast<FCDocument*>(GetDocument()), NULL, FCDEntity::EMITTER);
	else if (_clone->HasType(FCDEmitterInstance::GetClassType())) clone = (FCDEmitterInstance*) _clone;

	Parent::Clone(_clone);

	if (clone != NULL)
	{
		for (FCDMaterialInstanceContainer::const_iterator it = materialInstances.begin(); it != materialInstances.end(); ++it)
		{
			FCDMaterialInstance* cloneMaterialInstance = clone->AddMaterialInstance();
			(*it)->Clone(cloneMaterialInstance);
		}
	}

	return _clone;
}

FCDMaterialInstance* FCDEmitterInstance::AddMaterialInstance()
{
	FCDMaterialInstance* instance = materialInstances.Add(this);
	SetDirtyFlag();
	return instance;
}

FCDMaterialInstance* FCDEmitterInstance::AddMaterialInstance(FCDMaterial* material, FCDGeometryPolygons* polygons)
{
	FCDMaterialInstance* instance = AddMaterialInstance();
	if (material != NULL) instance->SetMaterial(material);
	if (polygons != NULL)
	{
		const fstring& semantic = polygons->GetMaterialSemantic();
		if (!semantic.empty())
		{
			instance->SetSemantic(polygons->GetMaterialSemantic());
		}
		else
		{
			// Generate a semantic.
			fstring semantic = TO_FSTRING(material->GetDaeId()) + TO_FSTRING(polygons->GetFaceOffset());
			polygons->SetMaterialSemantic(semantic);
			instance->SetSemantic(semantic);
		}
	}
	return instance;
}

bool FCDEmitterInstance::LoadFromXML(xmlNode* instanceNode)
{
	bool status = Parent::LoadFromXML(instanceNode);
	if (!status) return status;

	if (GetEntity() == NULL && !IsExternalReference())
	{
		FUError::Error(FUError::ERROR, FUError::ERROR_INVALID_URI, instanceNode->line);
	}

	// Check for the expected instantiation node type
	if (!IsEquivalent(instanceNode->name, DAE_INSTANCE_EMITTER_ELEMENT))
	{
		FUError::Error(FUError::ERROR, FUError::ERROR_UNKNOWN_ELEMENT, instanceNode->line);
	}

	// Look for the <bind_material> element. The others are discarded for now.
	xmlNode* bindMaterialNode = FindChildByType(instanceNode, DAE_BINDMATERIAL_ELEMENT);
	if (bindMaterialNode != NULL)
	{
		// Retrieve the list of the <technique_common><instance_material> elements.
		xmlNode* techniqueNode = FindChildByType(bindMaterialNode, DAE_TECHNIQUE_COMMON_ELEMENT);
		xmlNodeList materialNodes;
		FindChildrenByType(techniqueNode, DAE_INSTANCE_MATERIAL_ELEMENT, materialNodes);
		for (xmlNodeList::iterator itM = materialNodes.begin(); itM != materialNodes.end(); ++itM)
		{
			FCDMaterialInstance* material = AddMaterialInstance();
			status &= (material->LoadFromXML(*itM));
		}
	}

	SetDirtyFlag();
	return status;
}

bool FCDEmitterInstance::LoadFromExtra(FCDENode* instanceNode)
{
	bool status = Parent::LoadFromExtra(instanceNode);
	if (!status) return status;

	if (GetEntity() == NULL && !IsExternalReference())
	{
		FUError::Error(FUError::ERROR, FUError::ERROR_INVALID_URI);
	}

	// Check for the expected instantiation node type
	if (!IsEquivalent(instanceNode->GetName(), DAE_INSTANCE_EMITTER_ELEMENT))
	{
		FUError::Error(FUError::ERROR, FUError::ERROR_UNKNOWN_ELEMENT);
	}

	// Look for the <bind_material> element. The others are discarded for now.
	FCDENode* bindMaterialNode = instanceNode->FindChildNode(DAE_BINDMATERIAL_ELEMENT);
	if (bindMaterialNode != NULL)
	{
		// Retrieve the list of the <technique_common><instance_material> elements.
		FCDENode* techniqueNode = bindMaterialNode->FindChildNode(DAE_TECHNIQUE_COMMON_ELEMENT);
		FCDENodeList materialNodes;
		techniqueNode->FindChildrenNodes(DAE_INSTANCE_MATERIAL_ELEMENT, materialNodes);
		for (FCDENodeList::iterator itM = materialNodes.begin(); itM != materialNodes.end(); ++itM)
		{
			FCDMaterialInstance* material = AddMaterialInstance();
			status &= (material->LoadFromExtra(*itM));
		}
	}

	SetDirtyFlag();
	return status;
}

FCDENode* FCDEmitterInstance::WriteToExtra(FCDENode* parentNode) const
{
	FCDENode* instanceNode = Parent::WriteToExtra(parentNode);
	if (!materialInstances.empty())
	{
		FCDENode* bindMaterialNode = instanceNode->AddChildNode(DAE_BINDMATERIAL_ELEMENT);
		FCDENode* techniqueCommonNode = bindMaterialNode->AddChildNode(DAE_TECHNIQUE_COMMON_ELEMENT);
		for (FCDMaterialInstanceContainer::const_iterator itM = materialInstances.begin(); itM != materialInstances.end(); ++itM)
		{
			(*itM)->WriteToExtra(techniqueCommonNode);
		}
	}
	return instanceNode;
}

xmlNode* FCDEmitterInstance::WriteToXML(xmlNode* parentNode) const
{
	xmlNode* instanceNode = Parent::WriteToXML(parentNode);
	if (!materialInstances.empty())
	{
		xmlNode* bindMaterialNode = AddChild(instanceNode, DAE_BINDMATERIAL_ELEMENT);
		xmlNode* techniqueCommonNode = AddChild(bindMaterialNode, DAE_TECHNIQUE_COMMON_ELEMENT);
		for (FCDMaterialInstanceContainer::const_iterator itM = materialInstances.begin(); itM != materialInstances.end(); ++itM)
		{
			(*itM)->WriteToXML(techniqueCommonNode);
		}
	}
	return instanceNode;
}
