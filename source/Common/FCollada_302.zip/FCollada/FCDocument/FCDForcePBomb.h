/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/

/**
	@file FCDForcePBomb.h
	This file contains the FCDForcePBomb class.
*/

#ifndef _FCD_FORCE_PBOMB_H_
#define _FCD_FORCE_PBOMB_H_

#endif // _FCD_FORCE_PBOMB_H_
