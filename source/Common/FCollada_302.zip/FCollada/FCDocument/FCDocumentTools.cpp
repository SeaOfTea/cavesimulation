/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/

#include "StdAfx.h"
#include "FCDocument/FCDocument.h"
#include "FCDocument/FCDocumentTools.h"
#include "FCDocument/FCDAnimated.h"
#include "FCDocument/FCDAnimation.h"
#include "FCDocument/FCDAnimationChannel.h"
#include "FCDocument/FCDAnimationCurve.h"
#include "FCDocument/FCDAsset.h"
#include "FCDocument/FCDController.h"
#include "FCDocument/FCDGeometry.h"
#include "FCDocument/FCDGeometryMesh.h"
#include "FCDocument/FCDGeometryPolygons.h"
#include "FCDocument/FCDGeometrySource.h"
#include "FCDocument/FCDGeometrySpline.h"
#include "FCDocument/FCDGeometryNURBSSurface.h"
#include "FCDocument/FCDLibrary.h"
#include "FCDocument/FCDSceneNode.h"
#include "FCDocument/FCDSkinController.h"
#include "FCDocument/FCDTransform.h"

//
// FCDocumentTools
// 

namespace FCDocumentTools
{
	class FCDConversionSwapFunctor
	{
	private:
		enum Axis { X, Y, Z, UNKNOWN } current, target;
		Axis ConvertVector(const FMVector3& v)
		{
			if (IsEquivalent(v, FMVector3::XAxis)) return X;
			else if (IsEquivalent(v, FMVector3::YAxis)) return Y;
			else if (IsEquivalent(v, FMVector3::ZAxis)) return Z;
			else return UNKNOWN;
		}

		typedef void (*ConversionFn) (FMVector3& data);
		ConversionFn functor;

	public:
		FCDConversionSwapFunctor(const FMVector3& targetAxis)
			:	current(UNKNOWN), target(UNKNOWN)
		{
			target = ConvertVector(targetAxis);
		};

		inline void SetCurrent(const FMVector3& axis)
		{
			current = ConvertVector(axis);
			PrepareFunctor();
		}

		inline bool RequiresPivotTransform() { return functor != Identity; }

		void SetPivotTransform(FCDSceneNode* node)
		{
			if (functor == Identity) return;
			
			// Change out of the current up-axis into Y-up.
			if (current == X)
			{
				FCDTRotation* rotate = (FCDTRotation*) node->AddTransform(FCDTransform::ROTATION);
				rotate->SetAxis(FMVector3::ZAxis);
				rotate->SetAngle(-90.0f);
			}
			else if (current == Z)
			{
				FCDTRotation* rotate = (FCDTRotation*) node->AddTransform(FCDTransform::ROTATION);
				rotate->SetAxis(FMVector3::XAxis);
				rotate->SetAngle(-90.0f);
			}

			// Change into the target up-axis.
			if (target == X)
			{
				FCDTRotation* rotate = (FCDTRotation*) node->AddTransform(FCDTransform::ROTATION);
				rotate->SetAxis(FMVector3::ZAxis);
				rotate->SetAngle(90.0f);
			}
			else if (target == Z)
			{
				FCDTRotation* rotate = (FCDTRotation*) node->AddTransform(FCDTransform::ROTATION);
				rotate->SetAxis(FMVector3::XAxis);
				rotate->SetAngle(90.0f);
			}
		}

		void operator() (FMVector3& data) { (*functor)(data); }

	private:
		void PrepareFunctor()
		{
			if (target == UNKNOWN || current == UNKNOWN || target == current) functor = Identity;
			else
			{
				switch (target)
				{
				case X: functor = (current == Y) ? XtoY : XtoZ; break;
				case Y: functor = (current == X) ? YtoX : YtoZ; break;
				case Z:	functor = (current == X) ? ZtoX : ZtoY; break;
				}
			}
		}

		static void Identity(FMVector3& UNUSED(data)) {}
		static void XtoY(FMVector3& data) { float t = -data.x; data.x = data.y; data.y = t; }
		static void XtoZ(FMVector3& data) { float t = data.x; data.x = data.y; data.y = data.z; data.z = t; }
		static void YtoX(FMVector3& data) { float t = data.x; data.x = -data.y; data.y = t; }
		static void YtoZ(FMVector3& data) { float t = -data.y; data.y = data.z; data.z = t; }
		static void ZtoX(FMVector3& data) { float t = data.z; data.z = data.y; data.y = data.x; data.x = t; }
		static void ZtoY(FMVector3& data) { float t = data.y; data.y = -data.z; data.z = t; }
	};

	class FCDConversionUnitFunctor
	{
	private:
		float factor, target;

	public:
		FCDConversionUnitFunctor(float _target)
			:	target(_target), factor(1.0f) {}

		void SetCurrent(float current) { factor = (current <= 0.0f) ? 1.0f : (target / current); }
		void operator() (float& data) { data *= factor; }
		void operator() (FMVector3& data) { data *= factor; }
	};

	static void GetAssetFunctors(FCDEntity* entity, FCDConversionUnitFunctor& lengthFunctor, FCDConversionSwapFunctor& upAxisFunctor)
	{
		FCDAssetList assets; assets.reserve(3);
		entity->GetHierarchicalAssets(assets);
		bool hasLength = false;
		bool hasAxis = false;
		for (FCDAssetList::iterator it = assets.begin(); it != assets.end(); ++it)
		{
			if (!hasLength && (*it)->HasUnits()) { hasLength = true; lengthFunctor.SetCurrent((*it)->GetUnitConversionFactor()); }
			if (!hasAxis && (*it)->HasUpAxis()) { hasAxis = true; upAxisFunctor.SetCurrent((*it)->GetUpAxis()); }
		}
		if (!hasLength) lengthFunctor.SetCurrent(-1.0f);
		if (!hasAxis) upAxisFunctor.SetCurrent(FMVector3::Origin);
	}

	inline void ResetAsset(FCDEntity* entity)
	{
		FCDAsset* asset = const_cast<FCDAsset*>(const_cast<const FCDEntity*>(entity)->GetAsset());
		if (asset != NULL)
		{
			asset->ResetUnits();
			asset->ResetUpAxis(); 
		}
	}

	void StandardizeUpAxisAndLength(FCDocument* document, const FMVector3& upAxis, float unitInMeters)
	{
		if (document == NULL) return;

		// Setup the modification functors.
		FCDConversionUnitFunctor lengthFunctor((IsEquivalent(unitInMeters, 0.0f) || unitInMeters < 0.0f) ? document->GetAsset()->GetUnitConversionFactor() : unitInMeters);
		FCDConversionSwapFunctor upAxisFunctor(IsEquivalent(upAxis, FMVector3::Origin) ? document->GetAsset()->GetUpAxis() : upAxis);
#define CONVERT_FL(f) { lengthFunctor(f); }
#define CONVERT_VECT3(v) { upAxisFunctor(v); }
#define CONVERT_VECT3L(v) { upAxisFunctor(v); lengthFunctor(v); }
#define CONVERT_MAT44(m) { upAxisFunctor(*(FMVector3*) (m)[0]); upAxisFunctor(*(FMVector3*) (m)[1]); upAxisFunctor(*(FMVector3*) (m)[2]); upAxisFunctor(*(FMVector3*) (m)[3]); lengthFunctor((m)[3][0]); lengthFunctor((m)[3][1]); lengthFunctor((m)[3][2]); }

		// Iterate over the scene graph, modifying the transforms.
		FCDSceneNodeList queue;
		for (size_t i = 0; i < document->GetVisualSceneLibrary()->GetEntityCount(); ++i) queue.push_back(document->GetVisualSceneLibrary()->GetEntity(i));
		while (!queue.empty())
		{
			FCDSceneNode* node = queue.back(); queue.pop_back();
			GetAssetFunctors(node, lengthFunctor, upAxisFunctor);
			queue.insert(queue.end(), node->GetChildren().begin(), node->GetChildren().end());
			for (FCDTransformList::iterator it = node->GetTransforms().begin(); it != node->GetTransforms().end(); ++it)
			{
				if ((*it)->HasType(FCDTTranslation::GetClassType())) CONVERT_VECT3L(((FCDTTranslation*) (*it))->GetTranslation())
				else if ((*it)->HasType(FCDTRotation::GetClassType())) CONVERT_VECT3(((FCDTRotation*) (*it))->GetAxis())
				else if ((*it)->HasType(FCDTScale::GetClassType())) CONVERT_VECT3(((FCDTScale*) (*it))->GetScale())
				else if ((*it)->HasType(FCDTSkew::GetClassType())) { CONVERT_VECT3(((FCDTSkew*) (*it))->GetRotateAxis()); CONVERT_VECT3(((FCDTSkew*) (*it))->GetAroundAxis()); }
				else if ((*it)->HasType(FCDTLookAt::GetClassType())) { CONVERT_VECT3L(((FCDTLookAt*) (*it))->GetPosition()); CONVERT_VECT3L(((FCDTLookAt*) (*it))->GetTarget()); CONVERT_VECT3L(((FCDTLookAt*) (*it))->GetUp()); }
				else if ((*it)->HasType(FCDTMatrix::GetClassType())) CONVERT_MAT44(((FCDTMatrix*) (*it))->GetTransform())
			}

			if (upAxisFunctor.RequiresPivotTransform())
			{
				// Unfortunately, some of the entity types do not survive very well on up-axis changes.
				// Check for cameras, lights, emitters, force fields
				FCDEntityInstanceList toRemove;
				for (FCDEntityInstanceContainer::iterator it  = node->GetInstances().begin(); it != node->GetInstances().end(); ++it)
				{
					if ((*it)->GetEntityType() == FCDEntity::CAMERA || (*it)->GetEntityType() == FCDEntity::LIGHT
						|| (*it)->GetEntityType() == FCDEntity::FORCE_FIELD || (*it)->GetEntityType() == FCDEntity::EMITTER)
					{
						FCDSceneNode* pivotNode = node->AddChildNode();
						pivotNode->SetName(node->GetName() + FC("_pivot"));
						pivotNode->SetDaeId(node->GetDaeId() + "_pivot");
						upAxisFunctor.SetPivotTransform(pivotNode);
						FCDEntityInstance* clone = pivotNode->AddInstance((*it)->GetEntityType());
						(*it)->Clone(clone);
						toRemove.push_back(*it);
					}
				}
				CLEAR_POINTER_VECTOR(toRemove);
			}

			ResetAsset(node);
		}

		// Iterate over the skin controllers: need to convert the bind-poses.
		size_t controllerCount = document->GetControllerLibrary()->GetEntityCount();
		for (size_t i = 0; i < controllerCount; ++i)
		{
			FCDController* controller = document->GetControllerLibrary()->GetEntity(i);
			if (controller->IsSkin())
			{
				GetAssetFunctors(controller, lengthFunctor, upAxisFunctor);
				FCDSkinController* skin = controller->GetSkinController();
				CONVERT_MAT44(skin->GetBindShapeTransform());
				for (FMMatrix44List::iterator it = skin->GetBindPoses().begin(); it != skin->GetBindPoses().end(); ++it) CONVERT_MAT44(*it)
				ResetAsset(controller);
			}
		}

		// Iterate over the geometries. Depending on the type, convert the control points, the normals and all other 3D data.
		size_t geometryCount = document->GetGeometryLibrary()->GetEntityCount();
		for (size_t i = 0; i < geometryCount; ++i)
		{
			FCDGeometry* geometry = document->GetGeometryLibrary()->GetEntity(i);
			GetAssetFunctors(geometry, lengthFunctor, upAxisFunctor);
			if (geometry->IsMesh())
			{
				// Iterate over the sources. Convert the source data depending on the stride and the type.
				FCDGeometryMesh* mesh = geometry->GetMesh();
				for (FCDGeometrySourceContainer::iterator it = mesh->GetSources().begin(); it != mesh->GetSources().end(); ++it)
				{
					FCDGeometrySource* source = (*it);
					uint32 stride = source->GetSourceStride();
					size_t count = source->GetSourceData().size() / stride;
					if (count == 0) continue;

					float* ptr = &source->GetSourceData().front();
					switch (source->GetSourceType())
					{
					case FUDaeGeometryInput::POSITION:
						if (stride >= 3) for (uint32 j = 0; j < count; ++j) { CONVERT_VECT3(*(FMVector3*) (ptr + j * stride)); }
						for (uint32 j = 0; j < count * stride; ++j) CONVERT_FL(ptr[j])
						break;

					case FUDaeGeometryInput::NORMAL:
					case FUDaeGeometryInput::GEOTANGENT:
					case FUDaeGeometryInput::GEOBINORMAL:
					case FUDaeGeometryInput::TEXTANGENT:
					case FUDaeGeometryInput::TEXBINORMAL:
						if (stride >= 3) for (uint32 j = 0; j < count; ++j) { CONVERT_VECT3(*(FMVector3*) (ptr + j * stride)); }
						break;
					}
				}
			}
			else if (geometry->IsSpline())
			{
				FCDGeometrySpline* spline = geometry->GetSpline();
				size_t elementCount = spline->GetSplineCount();
				for (size_t j = 0; j < elementCount; ++j)
				{
					FCDSpline* element = spline->GetSpline(j);
					for (FMVector3List::iterator it2 = element->GetCVs().begin(); it2 != element->GetCVs().end(); ++it2) CONVERT_VECT3L(*it2)
				}
			}

			ResetAsset(geometry);
		}

#undef CONVERT_FL
#undef CONVERT_VECT3
#undef CONVERT_VECT3L
#undef CONVERT_MAT44
	}
};
