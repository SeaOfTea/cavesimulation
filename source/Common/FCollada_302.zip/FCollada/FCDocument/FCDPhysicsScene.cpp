/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/
/*
	Based on the FS Import classes:
	Copyright (C) 2005-2006 Feeling Software Inc
	Copyright (C) 2005-2006 Autodesk Media Entertainment
	MIT License: http://www.opensource.org/licenses/mit-license.php
*/

#include "StdAfx.h"
#include "FCDocument/FCDocument.h"
#include "FCDocument/FCDPhysicsModel.h"
#include "FCDocument/FCDPhysicsModelInstance.h"
#include "FCDocument/FCDPhysicsScene.h"
#include "FUtils/FUDaeParser.h"
#include "FUtils/FUDaeWriter.h"
#include "FUtils/FUFileManager.h"
#include "FUtils/FUStringConversion.h"
#include "FCDocument/FCDExtra.h"
using namespace FUDaeParser;
using namespace FUDaeWriter;

ImplementObjectType(FCDPhysicsScene);

FCDPhysicsScene::FCDPhysicsScene(FCDocument* document)
:	FCDEntity(document, "PhysicsSceneNode")
,	gravity(0.0f, -9.8f, 0.0f), timestep(1.0f)
{
}

FCDPhysicsScene::~FCDPhysicsScene()
{
}

FCDEntity* FCDPhysicsScene::Clone(FCDEntity* _clone, bool cloneChildren) const
{
	FCDPhysicsScene* clone = NULL;
	if (_clone == NULL) _clone = clone = new FCDPhysicsScene(const_cast<FCDocument*>(GetDocument()));
	else if (_clone->HasType(FCDPhysicsScene::GetClassType())) clone = (FCDPhysicsScene*) _clone;

	Parent::Clone(_clone, cloneChildren);
	
	if (clone == NULL)
	{
		// Clone the miscellaneous parameters
		clone->gravity = gravity;
		clone->timestep = timestep;

		// Clone the physics model instances
		for (FCDPhysicsModelInstanceContainer::const_iterator it = instances.begin(); it != instances.end(); ++it)
		{
			FCDPhysicsModelInstance* clonedInstance = clone->AddInstance();
			(*it)->Clone(clonedInstance);
		}
	}
	return _clone;
}

FCDPhysicsModelInstance* FCDPhysicsScene::AddInstance(FCDPhysicsModel* model)
{
	FCDPhysicsModelInstance* instance = instances.Add(GetDocument());
	instance->SetEntity(model);
	SetDirtyFlag();
	return instance;
}

// Parse a <scene> or a <node> node from a COLLADA document
bool FCDPhysicsScene::LoadFromXML(xmlNode* sceneNode)
{
	bool status = FCDEntity::LoadFromXML(sceneNode);
	if (!status) return status;

	if(IsEquivalent(sceneNode->name, DAE_PHYSICS_SCENE_ELEMENT))
	{
		for (xmlNode* child = sceneNode->children; child != NULL; child = child->next)
		{
			if (child->type != XML_ELEMENT_NODE) continue;

			// Look for instantiation elements
			if (IsEquivalent(child->name, DAE_INSTANCE_PHYSICS_MODEL_ELEMENT)) 
			{
				FCDPhysicsModelInstance* instance = AddInstance(NULL);
				status &= (instance->LoadFromXML(child));
				continue; 
			}
			else if(IsEquivalent(child->name, DAE_TECHNIQUE_COMMON_ELEMENT))
			{
				xmlNode* gravityNode = FindChildByType(child, DAE_GRAVITY_ATTRIBUTE);
				if(gravityNode)
				{
					const char* gravityVal = ReadNodeContentDirect(gravityNode);
					gravity.x = FUStringConversion::ToFloat(&gravityVal);
					gravity.y = FUStringConversion::ToFloat(&gravityVal);
					gravity.z = FUStringConversion::ToFloat(&gravityVal);
				}
				xmlNode* timestepNode = FindChildByType(child, DAE_TIME_STEP_ATTRIBUTE);
				if(timestepNode)
				{
					timestep = FUStringConversion::ToFloat(ReadNodeContentDirect(timestepNode));
				}
			}
			else if (IsEquivalent(child->name, DAE_EXTRA_ELEMENT))
			{
				// The extra information is loaded by the FCDEntity class.
			}
		}
	}

	SetDirtyFlag();
	return status;
}

// Write out a <physics_scene> element to a COLLADA XML document
xmlNode* FCDPhysicsScene::WriteToXML(xmlNode* parentNode) const
{
	xmlNode* physicsSceneNode = WriteToEntityXML(parentNode, DAE_PHYSICS_SCENE_ELEMENT);
	if (physicsSceneNode == NULL) return physicsSceneNode;
	WriteToNodeXML(physicsSceneNode);

	return physicsSceneNode;
}

// Write out a <physics_scene>  element to a COLLADA XML document
void FCDPhysicsScene::WriteToNodeXML(xmlNode* node) const
{
	// Write out the instantiation
	for (FCDPhysicsModelInstanceContainer::const_iterator itI = instances.begin(); itI != instances.end(); ++itI)
	{
		const FCDEntityInstance* instance = (*itI);
		instance->WriteToXML(node);
	}

	// Add COMMON technique.
	xmlNode* techniqueNode = AddChild(node, DAE_TECHNIQUE_COMMON_ELEMENT);
	AddChild(techniqueNode, DAE_GRAVITY_ATTRIBUTE, TO_STRING(gravity));
	AddChild(techniqueNode, DAE_TIME_STEP_ATTRIBUTE, timestep);

	// Write out the extra information
	FCDEntity::WriteToExtraXML(node);
}
