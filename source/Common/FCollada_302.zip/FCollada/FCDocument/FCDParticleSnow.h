/*
    Copyright (C) 2005-2007 Feeling Software Inc.
    MIT License: http://www.opensource.org/licenses/mit-license.php
*/

#ifndef _FCD_SNOW_EMITTER_H_
#define _FCD_SNOW_EMITTER_H_

#ifndef _FCD_EMITTER_PARTICLE_H_
#include "FCDocument/FCDParticleSimple.h"
#endif // _FCD_EMITTER_H_


#endif
